import { useState } from 'react'

export default function App() {
  const [text, setText] = useState('Once upon a time, in a land of code and creativity...')
  const [audioUrl, setAudioUrl] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleGenerate = async () => {
    setLoading(true)
    setError('')
    setAudioUrl('')
    try {
      const res = await fetch('http://localhost:5000/api/tts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text })
      })

      if (!res.ok) {
        const err = await res.json().catch(() => ({}))
        throw new Error(err.error || `Request failed: ${res.status}`)
      }

      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      setAudioUrl(url)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{display:'flex', flexDirection:'column', alignItems:'center', gap:16, padding:24, fontFamily:'system-ui, sans-serif'}}>
      <h1>EchoVerse AI Audiobook Demo</h1>
      <textarea
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Enter text to narrate..."
        rows={10}
        style={{width: 'min(720px, 90vw)', padding:12, borderRadius:8, border:'1px solid #ccc'}}
      />
      <button
        onClick={handleGenerate}
        disabled={loading || !text.trim()}
        style={{padding:'10px 18px', borderRadius:10, border:'none', background:'#2563eb', color:'white', cursor:'pointer'}}
      >
        {loading ? 'Generating...' : 'Generate Audio'}
      </button>

      {error && <div style={{color:'crimson'}}>{error}</div>}
      {audioUrl && (
        <audio controls style={{marginTop: 12, width: 'min(720px, 90vw)'}}>
          <source src={audioUrl} type="audio/mpeg" />
        </audio>
      )}
      <p style={{opacity:.7, fontSize:14}}>Backend: Flask + gTTS | Frontend: React + Vite</p>
    </div>
  )
}
