# EchoVerse AI Audiobook Demo (Full Project)

A simple end-to-end demo that turns text into speech using a Flask backend (gTTS) and a React (Vite) frontend.

## 📦 Project Structure

```
echoverse_full_project/
├── backend/
│   ├── app.py
│   └── requirements.txt
└── frontend/
    ├── index.html
    ├── package.json
    ├── vite.config.js
    └── src/
        ├── App.jsx
        └── main.jsx
```

## 🚀 Setup & Run

### 1) Backend (Flask + gTTS)

```bash
cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
Backend will start at **http://localhost:5000**

> If you see an error like `gTTSError`, ensure your internet connection is active; gTTS calls Google TTS.

### 2) Frontend (React + Vite)

Open a second terminal:

```bash
cd frontend
npm install
npm run dev
```
Frontend dev server runs at **http://localhost:5173**

### 3) Use It

- Type or paste text in the textarea.
- Click **Generate Audio**.
- Wait for the MP3 to generate and play below.

## 🔧 Notes

- We enabled **CORS** in the backend so the frontend can call it during development.
- The backend streams back an **MP3** file. The frontend creates a temporary object URL to play it.
- For production, you might store files persistently or upload to object storage (S3, etc.).

## 🎙️ Upgrading Voices (Optional)

Swap gTTS with a provider such as **ElevenLabs**, **OpenAI TTS**, or **Google Cloud TTS**. These require API keys and offer high‑quality, expressive voices and multiple languages.

---

Made with ❤️ for your EchoVerse demo.
