from flask import Flask, request, send_file, jsonify
from flask_cors import CORS
from gtts import gTTS
import os
import uuid
import tempfile

app = Flask(__name__)
CORS(app)  # allow requests from the frontend dev server

@app.route("/api/health", methods=["GET"])
def health():
    return {"status": "ok"}

@app.route('/api/tts', methods=['POST'])
def text_to_speech():
    try:
        data = request.get_json(force=True)
    except Exception:
        return jsonify({"error": "Invalid JSON"}), 400

    text = (data or {}).get("text", "").strip()

    if not text:
        return jsonify({"error": "No text provided"}), 400

    # Create temp mp3 file
    tmp_dir = tempfile.gettempdir()
    filename = f"audio_{uuid.uuid4().hex}.mp3"
    filepath = os.path.join(tmp_dir, filename)

    try:
        tts = gTTS(text)
        tts.save(filepath)
    except Exception as e:
        return jsonify({"error": f"TTS failed: {e}"}), 500

    # Return file and delete after sending by using conditional cleanup
    return send_file(filepath, mimetype="audio/mpeg", as_attachment=True, download_name=filename)
    
if __name__ == '__main__':
    # Run on all interfaces so mobile/LAN can access if needed
    app.run(host='0.0.0.0', port=5000, debug=True)
